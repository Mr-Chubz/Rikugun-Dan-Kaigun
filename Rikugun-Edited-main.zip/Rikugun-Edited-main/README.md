# Project-Rikugun
This Unciv mod adds in land units for any faction.

v.1.1: Added in the Flaktank.

v.1.2: Balanced all the units.
